package com.polleria.polleria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolleriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
